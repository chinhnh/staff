<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChucvuModel extends Model {

    //
    public $table = 'tbl_chucvu';
    protected $primaryKey = 'chuc_vu_id';
    public $timestamps = false;

}
