<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PhongbanModel extends Model {

    public $table = 'tbl_phongban';
    public $primaryKey = 'phong_ban_id';
    public $timestamps = false;
   
}
